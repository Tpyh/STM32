#include "stm32f10x.h"
#include "stdio.h"

#include "Sys_Clock.h"
#include "Sys.h"
#include "Delay.h"
#include "mUSART.h"

#include "HC_SR04.h"
#include "LED.h"
#include "Key.h"
#include "L298N.h"

uint16_t printftick = 0;
uint16_t tick = 0;
uint16_t pwm_ccr1 = 400;
uint16_t pwm_ccr2 = 120;

int main()
{
	uint8_t keynum = 0;
	mNVIC_PriorityGroupGonfig(2);
	System_Init();
	mUSART_Init();
	LED_Init();
	Key_Init();
	L289N_Init(3599,449);
	PWM_CH1_Set(pwm_ccr1);
	PWM_CH2_Set(pwm_ccr2);
	PWM_Enable();
	
	while(1)
	{
		keynum = Key_Scan();
	
		
		Car_Wheel1(Foreword);
		Car_Wheel2(Foreword);
		
		if(keynum == KEY0)
		{
			if(pwm_ccr1 < 450)
				pwm_ccr1 += 20;
			else
				pwm_ccr1 = 0;
			PWM_CH1_Set(pwm_ccr1);
		}
		if(keynum == WK_UP)
		{
			if(pwm_ccr2 < 450)
				pwm_ccr2 += 20;
			else
				pwm_ccr2 = 0;
			PWM_CH2_Set(pwm_ccr2);
		}
		if(printftick == 10000)
		{
			tick++;
			printftick = 0;
		}
		if(tick == 15)
		{
			tick = 0;
			printf("pwm_ccr1 = %d\r\n",pwm_ccr1);
			printf("pwm_ccr2 = %d\r\n",pwm_ccr2);
		}
		printftick++;
	}

	
}


