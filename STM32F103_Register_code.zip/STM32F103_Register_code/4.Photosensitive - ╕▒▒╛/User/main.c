#include "stm32f10x.h"
#include "stdio.h"

#include "Sys_Clock.h"
#include "Sys.h"
#include "Delay.h"
#include "mUSART.h"

#include "HC_SR04.h"
#include "LED.h"
#include "Key.h"
#include "Photosen.h"


uint8_t key_num = 0;
int main()
{
	
	mNVIC_PriorityGroupGonfig(2);
	System_Init();
	mUSART_Init();
	mUSART2_Init();
	LED_Init();
	Key_Init();
	Key_Matrix_Init();
	ADC1_PA2_Init();
	
	while(1)
	{
		key_num = Key_MatrixScan();
//		printf("adc_vlaue = %f\r\n",Photosen_GetValue());
		if(key_num != 0)
			printf("key_num = %x\r\n",key_num);
		USART_SendString(USART1,"DSS");
		Delay_ms(1000);
	}
	
}

