#include "Sys.h"

#ifndef __MI2C_H
#define __MI2C_H

// I2C����ģ�⣺�˿ڶ���
#define I2C_PORT  GPIOB
#define I2C_SCL_PIN    (1<<10)  
#define I2C_SDA_PIN		 (1<<11)

#define I2C_SCL_SET()    	GPIO_Pin_Set(I2C_PORT,I2C_SCL_PIN,SET)   
#define I2C_SCL_RESET()  	GPIO_Pin_Set(I2C_PORT,I2C_SCL_PIN,RESET) 
#define I2C_SDA_SET()			GPIO_Pin_Set(I2C_PORT,I2C_SDA_PIN,SET)
#define I2C_SDA_RESET()		GPIO_Pin_Set(I2C_PORT,I2C_SDA_PIN,RESET)
#define I2C_SDA_Read()    GPIO_Read_Pin(I2C_PORT,I2C_SDA_PIN)

#endif
