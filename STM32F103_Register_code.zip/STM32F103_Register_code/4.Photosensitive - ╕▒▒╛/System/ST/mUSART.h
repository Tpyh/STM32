#ifndef __MUSART_H_
#define __MUSART_H_


void mUSART_Init(void);
void USART_SendByte(USART_TypeDef* USARTX,uint8_t Data);
void USART_SendString(USART_TypeDef* USARTX,char *str);
void USART1_IRQHandler(void);
void mUSART2_Init(void);






#endif

