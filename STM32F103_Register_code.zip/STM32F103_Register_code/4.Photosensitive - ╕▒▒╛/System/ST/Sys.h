#ifndef __SYS_H
#define __SYS_H

#define GPIO_PIN_12 (1<<12)
#define GPIO_PIN_13 (1<<13)


#define GPIO_PIN_SET 1
#define GPIO_PIN_RESET 0

#define GPIO_PUPD_PU 		(uint8_t)0x01
#define GPIO_PUPD_PD 		(uint8_t)0x00
#define GPIO_PUPD_NONE 	(uint8_t)0x00
/*--------------------GPIO_Otype---------------------*/

/*������ģʽ��*/
#define GPIO_AIN    	(uint8_t)0x00 //ģ������ģʽ
#define GPIO_FIN			(uint8_t)0x01 //��������ģʽ
#define GPIO_PUPD 	(uint8_t)0x02 //����/��������ģʽ


/*�����ģʽ��*/
#define GPIO_OTYPE_PP    	(uint8_t)0x00 //ͨ���������ģʽ
#define GPIO_OTYPE_LO			(uint8_t)0x01 //ͨ�ÿ�©���ģʽ
#define GPIO_OTYPE_AFPP 	(uint8_t)0x02 //���ù����������ģʽ
#define GPIO_OTYPE_AFLO 	(uint8_t)0x03 //���ù��ܿ�©���ģʽ
/*-----------------------------------------*/


#define GPIO_IN_MODE        (uint8_t)0x00
#define GPIO_OUT_MODE_10MHz (uint8_t)0x01
#define GPIO_OUT_MODE_2MHz 	(uint8_t)0x02
#define GPIO_OUT_MODE_50MHz (uint8_t)0x03

void GPIO_Pin_Set(GPIO_TypeDef * GPIOx,uint16_t GPIO_PIN,uint8_t State);
uint8_t GPIO_Read_Pin(GPIO_TypeDef * GPIOx,uint16_t GPIO_PIN);
void mNVIC_PriorityGroupGonfig(uint32_t NVIC_PriorityGroup);
void mNVIC_PrioritySet(uint16_t pre,uint16_t sub,uint8_t NVIC_Channel,uint8_t group);
void mNVIC_PriorityPower(uint8_t power,uint8_t NVIC_Channel);
void Px_OUT_PP_50MHz(GPIO_TypeDef * GPIOx,uint16_t pin);
void Px_OUT_PP_10MHz(GPIO_TypeDef * GPIOx,uint16_t pin);
void Px_SET_IN(GPIO_TypeDef * GPIOx,uint16_t pin,uint8_t pupd);
void Px_OUT_AFPP_50MHz(GPIO_TypeDef * GPIOx,uint16_t pin);



#endif

