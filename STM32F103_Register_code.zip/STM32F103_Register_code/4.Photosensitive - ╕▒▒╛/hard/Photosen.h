#ifndef _PHOTOSEN_H
#define _PHOTOSEN_H



void ADC1_PA2_Init(void);
uint16_t ADC1_GetVlaue(void);
float Photosen_GetValue(void);





#endif

