#include "stm32f10x.h"
#include "stdio.h"
#include "Sys.h"



void mUSART_Init()
{
	RCC->APB2ENR |= 1<<14;  //USART时钟使能
	RCC->APB2ENR |= 1<<2;   //GPIOA时钟使能
	
	GPIOA->CRH |= (0xB<<4); //PA9设置为复用推挽输出
	GPIOA->CRH &= ~(15<<8);//PA10设置为输入模式
  GPIOA->CRH |= (4<<8);	
	
	USART1->CR1 = 0x0;
	USART1->CR2 = 0x0;
	USART1->CR3 = 0x0;
	USART1->BRR = 0x271; //波特率设置：USARTDIV = 72000000/(115200 * 16) = 39.0625 转换为十六进制则为0x271 ，高八位存整数，低4位存（小数 * 16） 
	

	SET_BIT(USART1->CR1,USART_CR1_RXNEIE); //开启RXNE（接收）中断
	mNVIC_PrioritySet(2,2,USART1_IRQn,2);//中断优先级设置
	SET_BIT(USART1->CR1,USART_CR1_TE); //开启发送
	SET_BIT(USART1->CR1,USART_CR1_RE); //开启接收
	
	SET_BIT(USART1->CR1,USART_CR1_UE); //开启USART1

	
}

void USART_SendByte(USART_TypeDef* USARTX,uint8_t Data)
{
	USARTX->DR = (Data & (uint16_t)0x1ff);
	while((READ_BIT(USARTX->SR,USART_SR_TXE)) == 0); //等待TXE为空
	
}

void USART_SendString(USART_TypeDef* USARTX,char *str)
{
	uint32_t k = 0;
	
	do
	{
		USART_SendByte(USARTX,*(str + k));
		k++;
	}while(*(str+k) != '\0');
	
	while((READ_BIT(USARTX->SR,USART_SR_TC)) == 0); //等待发送完成
}

//USART1接收中断

void USART1_IRQHandler()
{
	uint8_t ucTemp;
	
	if(READ_BIT(USART1->SR,USART_SR_RXNE)) //RDR是否为空，不为空则执行程序段
	{
		ucTemp = USART1->DR & ((uint16_t) 0x1ff);
		USART_SendByte(USART1,ucTemp); //发送回串口
	}
}

//printf重定向
int fputc(int ch,FILE *f)
{
	uint8_t temp = {ch};
	USART_SendByte(USART1,temp);
	return ch;
}
