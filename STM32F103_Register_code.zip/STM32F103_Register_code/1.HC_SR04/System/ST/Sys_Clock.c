#include "stm32f10x.h"

void SetSysClock(){
		
		//1.开启外部时钟 HSE
		RCC->CR |= 1 << 16;
		//等待外部时钟HSE就绪
		while ((RCC->CR & (1 << 17)) == 0);
		
		//2. PLLCLK设置
		//设置 PLL 倍频系数 9倍频
		RCC->CFGR |= 7 << 18;
		//设置 HSE 作为 PLLCLK 输入源
		RCC->CFGR |= 1 << 16;
		
		//3. 打开 PLL 电路
		RCC->CR |= 1 << 24;
		//等待 PLL 电路就绪
		while ((RCC->CR & (1 << 25)) == 0);
		
		/* 使能预缓存 */
		FLASH->ACR |= 1<<4;

		//4. 设置 FLASH 时延:等待两个周期，让HSE能正常工作
    FLASH->ACR &= 3<<0;
		FLASH->ACR |= 1<<1;
		
		//5.AHB(不分频)、APB1、APB2清零(不分频),设置 APB1 预分频系数为2,APB1时钟不超过36MHz
		RCC->CFGR &= ~((0xF<<4)|(0x7<<8)|(0x7<<11));
		RCC->CFGR |= 1 << 10;	
			
		//6. SYSCLK设置
		//设置 PLL 作为 SYSCLK 输入源
		RCC->CFGR |= 1 << 1;
		//等待 SYSCLK 就绪
		while ((RCC->CFGR & (1 << 3)) == 0) {};
		
}

void System_Init(void)
{
	RCC->CR |= 0x00000001;	//设置系统默认复位初始化时钟为内部高速时钟HSI，CR复位值0x0000xx83
	RCC->CFGR |= 0x00000000;//复位CFGR寄存器：1.时钟输出，2.USB时钟选择，3.PLL，4.ADC，5.APB2，6.APB1，7.AHB，8.系统时钟切换
	RCC->CR &= 0xFEF6FFFF;	//复位（清零）PLLON,CSSON,HSEON（关闭PLL、时钟监测CSS、HES）
	RCC->CR &= 0xFFFBFFFF;	//复位（清零）HSEBYP（HSE晶振不旁路）
	RCC->CFGR &= 0xFF80FFFF;//复位PLLSRC, PLLXTPRE, PLLMUL and USBPRE/OTGFSPRE，USB时钟为PLL1.5倍分频
	RCC->CIR = 0x009F0000;	//禁止中断，清除标志位
	SetSysClock();					//选择PLL作为系统时钟，HSE不分频作为PLL输入
	
  SCB->VTOR = (0<<29) | ((FLASH_BASE| 0x0)&0x1FFFFF80); /* 设置向量中断表到FLASH，偏移地址为0x0 */

}

