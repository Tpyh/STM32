#ifndef __SYS_CLOCK_
#define __SYS_CLOCK_

void System_Init(void);

#endif

