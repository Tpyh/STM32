#ifndef __SYS_H
#define __SYS_H


void GPIO_Init_Set(GPIO_TypeDef * GPIOx,uint16_t GPIO_Pin,uint8_t Mode,uint8_t Pupd,uint8_t Otype);
void GPIO_Pin_Set(GPIO_TypeDef * GPIOx,uint16_t GPIO_PIN,uint8_t State);
void mNVIC_PriorityGroupGonfig(uint32_t NVIC_PriorityGroup);
void mNVIC_PrioritySet(uint16_t pre,uint16_t sub,uint8_t NVIC_Channel,uint8_t group);
void mNVIC_PriorityPower(uint8_t power,uint8_t NVIC_Channel);




#endif

