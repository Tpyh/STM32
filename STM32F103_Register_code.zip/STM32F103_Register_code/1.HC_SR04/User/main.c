#include "stm32f10x.h"
#include "Sys_Clock.h"
#include "Sys.h"
#include "Delay.h"
#include "mUSART.h"
#include "stdio.h"
#include "HC_SR04.h"
#include "LED.h"
#include "Key.h"
uint8_t keynum = 0;

int main()
{
	mNVIC_PriorityGroupGonfig(2);
	System_Init();
	mUSART_Init();
	LED_Init();
	HC_SR04_Init();
	Key_Matrix();
	while(1)
	{
		keynum = Key_MatrixScan();
		LED_Set(LED0,ON);
//		printf("length = %fcm\r\n",HC_SR04_GetLength());
		if(keynum != 0)
		{	
			printf("keynum = %x\r\n",keynum);
			printf(" %d\r\n",GPIOE->IDR);
		}
	}

	
}


