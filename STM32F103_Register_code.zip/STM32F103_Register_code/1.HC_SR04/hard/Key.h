#ifndef __KEY_H
#define __KEY_H



#define KEY0 1
#define WK_UP 2
void Key_Init(void);
uint8_t Key_Scan(void);
void Key_Matrix(void);
void PE_SET_PUIN(uint8_t pin);
void PE_SET_OUT(uint8_t pin);

void PE4_7IN_PE8_11OUT(void);
void PE4_7OUT_PE8_11IN(void);
uint8_t Key_MatrixScan(void);

#endif
