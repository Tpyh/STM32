#include "stm32f10x.h"
#include "LED.h"
#include "Sys.h"

void LED_Init()
{
	SET_BIT(RCC->APB2ENR,RCC_APB2ENR_IOPEEN);
	
//	SET_BIT(GPIOE->CRH,(uint16_t)1<<16); //PE12推挽输出,LED0
//	SET_BIT(GPIOE->CRH,(uint16_t)1<<20); //PE13推挽输出,LED1
	GPIO_Init_Set(GPIOE,GPIO_PIN_12|GPIO_PIN_13,GPIO_OUT_MODE_10MHz,GPIO_PUPD_NONE,GPIO_OTYPE_PP);
	
	GPIOE->ODR |= (uint16_t)(1<<12);
	GPIOE->ODR |= (uint16_t)(1<<13);

	
}

//LEDx:LED0 OR LED1; 
//state: ON OR OFF
void LED_Set(uint8_t LEDx,uint8_t state)
{
	if(LEDx == LED0)
	{
		if(state == ON)
		{
					GPIOE->ODR &= (uint16_t)~(1<<12);

		}
		else if(state == OFF)
		{
					GPIOE->ODR |= (uint16_t)(1<<12);
		}
	}
	else if(LEDx == LED1)
	{
		if(state == ON)
		{
					GPIOE->ODR &= (uint16_t)~(1<<13);

		}
		else if(state == OFF)
		{
					GPIOE->ODR |= (uint16_t)(1<<13);

		}

	}
}




