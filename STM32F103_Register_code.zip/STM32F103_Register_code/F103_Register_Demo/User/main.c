#include "stm32f10x.h"
#include "Sys_Clock.h"
#include "Sys.h"
#include "Delay.h"
#include "mUSART.h"
#include "stdio.h"
#include "HC_SR04.h"
#include "LED.h"

uint16_t flag = 0;

int main()
{
	mNVIC_PriorityGroupGonfig(2);
	System_Init();
	mUSART_Init();
	LED_Init();
//	HC_SR04_Init();
	
	while(1)
	{
		LED_Set(LED0,ON);
//		printf("length = %fcm\r\n",HC_SR04_GetLength());
		Delay_ms(1000);
		LED_Set(LED0,OFF);
		Delay_ms(1000);
	}

	
}


