
#ifndef __LED_H_
#define __LED_H_

#define LED0 0
#define LED1 1
#define ON 0
#define OFF 1



void LED_Init(void);
void LED_Set(uint8_t LEDx,uint8_t state);


#endif
