#include "main.h"
#include "LED.h"

void iPx_OUT_PP_50MHz(GPIO_TypeDef * GPIOx,uint16_t pin)
{
	uint16_t i = 0;
	for(i = 0;i < 15;i++)
	{
		if(pin & 1<<i)
		{
			if(i <= 7)
			{	
				GPIOx->CRL &= ~((uint32_t)0xf<<(i*4));
				GPIOx->CRL |= (uint32_t)3<<(i*4);
			}
			else
			{
				GPIOx->CRH &= ~((uint32_t)0xf<<((i - 8)*4));
				GPIOx->CRH |= (uint32_t)3<<((i - 8)*4);
			}
		}
	}
}


void LED_Init()
{
	RCC->APB2ENR |= 1<<6;
	
	iPx_OUT_PP_50MHz(GPIOE,1<<12|1<<13);
	
	GPIOE->ODR |= (uint16_t)(1<<12);
	GPIOE->ODR |= (uint16_t)(1<<13);

}

//LEDx:LED0 OR LED1; 
//state: ON OR OFF
void LED_Set(uint8_t LEDx,uint8_t state)
{
	if(LEDx == LED0)
	{
		if(state == ON)
		{
				HAL_GPIO_WritePin(GPIOE,GPIO_PIN_12,GPIO_PIN_RESET);
		}
		else if(state == OFF)
		{
				HAL_GPIO_WritePin(GPIOE,GPIO_PIN_12,GPIO_PIN_SET);
		}
	}
	else if(LEDx == LED1)
	{
		if(state == ON)
		{
				HAL_GPIO_WritePin(GPIOE,GPIO_PIN_13,GPIO_PIN_RESET);
		}
		else if(state == OFF)
		{
				HAL_GPIO_WritePin(GPIOE,GPIO_PIN_13,GPIO_PIN_SET);
		}
	}
}




