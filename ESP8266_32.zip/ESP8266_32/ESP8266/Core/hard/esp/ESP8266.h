#include "main.h"
#include "usart.h"
#include "gpio.h"
#include "stdio.h"
#include "stm32f1xx_hal.h"

#ifndef __ESP8266_H
#define __ESP8266_H

void ESP8266_AP_MODE(void);
void ESP8266_AP_SendDATA(uint8_t * data,uint8_t id,uint8_t num);




#endif
