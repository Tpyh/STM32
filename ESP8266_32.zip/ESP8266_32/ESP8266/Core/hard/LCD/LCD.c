#include "LCD.h"
#include <stdlib.h>
#include <math.h>
#include "Font.h"
/*开发板与LCD相连接的端口初始化函数*/
void LCD_GPIO_Init()
{
	GPIO_InitTypeDef GPIO_InitStruct;
	
	//端口时钟使能
	__HAL_RCC_GPIOA_CLK_ENABLE();
	__HAL_RCC_GPIOB_CLK_ENABLE();
	__HAL_RCC_GPIOC_CLK_ENABLE();
	__HAL_RCC_GPIOD_CLK_ENABLE();
	
	
	//端口初始电平设置
	HAL_GPIO_WritePin(GPIOD,GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3|
													GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|
													GPIO_PIN_7|GPIO_PIN_8|GPIO_PIN_9|
													GPIO_PIN_10|GPIO_PIN_11|GPIO_PIN_12|
													GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15|
													GPIO_PIN_0,GPIO_PIN_RESET);
	
	HAL_GPIO_WritePin(GPIOC,GPIO_PIN_8|GPIO_PIN_9,GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOC,GPIO_PIN_10,GPIO_PIN_RESET);
	
	HAL_GPIO_WritePin(GPIOB,GPIO_PIN_4|GPIO_PIN_9,GPIO_PIN_SET);
	
	//端口初始化
	
	//GPIOD初始化:数据输出引脚
	GPIO_InitStruct.Pin = GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3|
												GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|
												GPIO_PIN_7|GPIO_PIN_8|GPIO_PIN_9|
												GPIO_PIN_10|GPIO_PIN_11|GPIO_PIN_12|
												GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15|
												GPIO_PIN_0;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;  //推挽输出
	GPIO_InitStruct.Pull = GPIO_NOPULL;    			 
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	
	HAL_GPIO_Init(GPIOD,&GPIO_InitStruct);
	
	//GPIOC初始化:PC9(LCD_CS):片选,PC8(LCD_RS):低电平为命令，高电平为数据,PC10(BL)：控制背光的亮灭
	GPIO_InitStruct.Pin = GPIO_PIN_8|GPIO_PIN_9|GPIO_PIN_10;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;  //推挽输出
	GPIO_InitStruct.Pull = GPIO_NOPULL;    			 
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	
	HAL_GPIO_Init(GPIOC,&GPIO_InitStruct);
	
	//GPIOB初始化:PB4(LCD_WR):写引脚,PB9(LCD_RD):读引脚
	GPIO_InitStruct.Pin = GPIO_PIN_4|GPIO_PIN_9;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;  //推挽输出
	GPIO_InitStruct.Pull = GPIO_NOPULL;    			 
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	
	HAL_GPIO_Init(GPIOB,&GPIO_InitStruct);	
	
}


/*LCD写命令函数*/
void LCD_WR_CMD(uint8_t cmd)
{
	LCD_CS_RESET();    //CS拉低:选中芯片；只有CS为低电平时，WR的数据才有效
	LCD_RS_RESET(); 	 //RS = 0,命令模式
	
	LCD_WR_RESET();    //拉低，准备发送命令，低电平时：发送方放数据
	GPIOD->ODR = cmd;  //发送命令  
	LCD_WR_SET();      //产生上升沿，ILI9341读命令，高电平时：接收方收数据
	
	LCD_CS_SET();      //拉高CS:不选中芯片
	
}


/*LCD写数据函数*/
void LCD_WR_DATA(uint16_t data)
{
	LCD_CS_RESET();    //CS拉低:选中芯片
	LCD_RS_SET(); 	 //RS = 1,数据模式
	
	LCD_WR_RESET();    //拉低，准备发送数据
	GPIOD->ODR = data;  //发送数据
	LCD_WR_SET();      //产生上升沿，ILI9341读数据
	
	LCD_CS_SET();      //拉高CS
	
}


/*ILI9341寄存器初始化函数*/
void ILI9341_HSD28_Initial(void) 
{ 
	// VCI=2.8V 
	//************* Reset LCD Driver ****************//
	LCD_WR_CMD(0x01); 
	HAL_Delay(1); // Delay 1ms 
	LCD_WR_CMD(0x00); 
	HAL_Delay(10); // Delay 10ms // This delay time is necessary 
	LCD_WR_CMD(0x01); 
	HAL_Delay(120); // Delay 120 ms 

	//************* Start Initial Sequence **********//
	LCD_WR_CMD(0xCF); 
	LCD_WR_DATA	(0x00); 
	LCD_WR_DATA (0xC1); 
	LCD_WR_DATA (0X30); 
	
	LCD_WR_CMD(0xED); 
	LCD_WR_DATA (0x64); 
	LCD_WR_DATA (0x03); 
	LCD_WR_DATA (0X12); 
	LCD_WR_DATA (0X81);
	
	LCD_WR_CMD(0xE8); 
	LCD_WR_DATA (0x85); 
	LCD_WR_DATA (0x00); 
	LCD_WR_DATA (0x7A); 
	
	LCD_WR_CMD(0xCB); 
	LCD_WR_DATA (0x39); 
	LCD_WR_DATA (0x2C); 
	LCD_WR_DATA (0x00); 
	LCD_WR_DATA (0x34); 
	LCD_WR_DATA (0x02);
	
	LCD_WR_CMD(0xF7); 
	LCD_WR_DATA (0x20); 


	LCD_WR_CMD(0xEA); 
	LCD_WR_DATA (0x00); 
	LCD_WR_DATA (0x00);
	
	LCD_WR_CMD(0xC0); //Power control 
	LCD_WR_DATA (0x21); //VRH[5:0] 
	
	LCD_WR_CMD(0xC1); //Power control 
	LCD_WR_DATA (0x11); //SAP[2:0];BT[3:0]
	
	LCD_WR_CMD(0xC5); //VCM control 
	LCD_WR_DATA (0x31); 
	LCD_WR_DATA (0x3C);
	
	LCD_WR_CMD(0xC7); //VCM control2 
	LCD_WR_DATA (0X9f); 
	
	LCD_WR_CMD(0x36); // Memory Access Control 
	LCD_WR_DATA (0x08); 
	
	LCD_WR_CMD(0xB1);  //设置帧速率
	LCD_WR_DATA (0x00); 
	LCD_WR_DATA (0x1A); //1B设置为1A，提高屏幕的刷新频率
	
	LCD_WR_CMD(0xB6); // Display Function Control 
	LCD_WR_DATA (0x0A); 
	LCD_WR_DATA (0xA2); 
	
	LCD_WR_CMD(0xF2); // 3Gamma Function Disable 
	LCD_WR_DATA (0x00); 
	
	LCD_WR_CMD(0x26); //Gamma curve selected 
	LCD_WR_DATA (0x01); 
	
	/*SET GAMMA*/
	LCD_WR_CMD(0xE0); //Set Gamma (伽马修正设置)：使显示效果更好
	LCD_WR_DATA (0x0F); 
	LCD_WR_DATA (0x2A); 
	LCD_WR_DATA (0x28); 
	LCD_WR_DATA (0x08); 
	LCD_WR_DATA (0x0E); 
	LCD_WR_DATA (0x08); 
	LCD_WR_DATA (0x54); 
	LCD_WR_DATA (0XA9); 
	LCD_WR_DATA (0x43); 
	LCD_WR_DATA (0x0A); 
	LCD_WR_DATA (0x0F); 
	LCD_WR_DATA (0x00); 
	LCD_WR_DATA (0x00); 
	LCD_WR_DATA (0x00); 
	LCD_WR_DATA (0x00); 
	
	LCD_WR_CMD(0XE1); //Set Gamma (伽马修正设置)
	LCD_WR_DATA (0x00); 
	LCD_WR_DATA (0x15); 
	LCD_WR_DATA (0x17); 
	LCD_WR_DATA (0x07); 
	LCD_WR_DATA (0x11); 
	LCD_WR_DATA (0x06); 
	LCD_WR_DATA (0x2B); 
	LCD_WR_DATA (0x56); 
	LCD_WR_DATA (0x3C); 
	LCD_WR_DATA (0x05); 
	LCD_WR_DATA (0x10); 
	LCD_WR_DATA (0x0F); 
	LCD_WR_DATA (0x3F); 
	LCD_WR_DATA (0x3F); 
	LCD_WR_DATA (0x0F); 
	
	
	/*设置像素格式*/
	LCD_WR_CMD(0x3A);  //设置像素格式为RGB565
	LCD_WR_DATA(0x55);
	
	
	LCD_Display_Windows(0); //窗口方向设置：1为横屏，0为竖屏
	
	//在上一个函数中，已设置，x与y的起始坐标，以下语句省略
	//	/*配置行(Y)列(X)的起始与结束坐标——设置显示窗口*/
	//	LCD_WR_CMD(0x2B);  //配置行(Y)起始位，0~319
	//	LCD_WR_DATA(0x00); //0行的低8位
	//	LCD_WR_DATA(0x00); //0行的高8位
	//	LCD_WR_DATA(0x01); //319行的低8位
	//	LCD_WR_DATA(0x3F); //319行的高8位

	//	LCD_WR_CMD(0x2A);  //配置列(X)起始位，0~239
	//	LCD_WR_DATA(0x00); //0列的低8位
	//	LCD_WR_DATA(0x00); //0列的高8位
	//	LCD_WR_DATA(0x00); //239列的低8位
	//	LCD_WR_DATA(0xEF); //239列的高8位
	
	/*退出睡眠模式*/
	LCD_WR_CMD(0x11); //复位后处于睡眠模式，这里退出
	HAL_Delay(120);   //等待要大于120ms
	
	/*打开显示*/
	LCD_WR_CMD(0x29);
	
	/*开背光*/
	LCD_BL_SET_HIGH();
	
}

/*设置显示窗口:dir:0:竖屏,1:横屏*/

void LCD_Display_Windows(uint16_t dir)
{
	slcd_t slcd;
	if(dir == 0)
	{
		slcd.width = 240;
		slcd.height = 320;
		LCD_WR_CMD(0x36); //设置屏幕方向命令
		LCD_WR_DATA(0x08); //竖屏
	}	
	else
	{
		slcd.width = 320;
		slcd.height = 240;
		LCD_WR_CMD(0x36); //设置屏幕方向命令
		LCD_WR_DATA(0xA8); //竖屏
	}	
	
	//设置显示窗口(分辨率)
	LCD_WR_CMD(0x2A); //设置宽度
	LCD_WR_DATA(0);
	LCD_WR_DATA(0);
	LCD_WR_DATA(slcd.width/256);//发送窗口宽度设置高八位数据
	LCD_WR_DATA(slcd.width%256);//低八位
	
	LCD_WR_CMD(0x2B); //设置宽度
	LCD_WR_DATA(0);
	LCD_WR_DATA(0);
	LCD_WR_DATA(slcd.height/256);//发送窗口宽度设置高八位数据
	LCD_WR_DATA(slcd.height%256);//低八位

}


void LCD_Init(void)
{
	LCD_GPIO_Init();
	ILI9341_HSD28_Initial();
}



/*设置像素坐标，Xpos:0~239,Ypos:0~319*/

void LCD_SetCursor(uint16_t Xpos,uint16_t Ypos)
{
	LCD_WR_CMD(0x2A); //设置x坐标
	
	LCD_WR_DATA(Xpos>>8); //高8位
	LCD_WR_DATA(Xpos&0xFF);//低8位
	
	LCD_WR_CMD(0x2B); //设置y坐标
	
	LCD_WR_DATA(Ypos>>8); //高8位
	LCD_WR_DATA(Ypos&0xFF);//低8位
	
}

/*清屏函数，color:清屏填充颜色*/

void LCD_Clear(uint16_t color)
{
	uint32_t i = 0;
	uint32_t tolapoint = 240 * 320; 
	
	LCD_SetCursor(0,0); //设置初始光标位置
	LCD_WR_CMD(0x2C); //发送写显存指令
	
	for(i = 0;i< tolapoint;i++)
		LCD_WR_DATA(color);

}

/*显示点*/
void LCD_ShowPoint(uint16_t x,uint16_t y,uint16_t color)
{
	LCD_SetCursor(x,y); //坐标设置
	
	LCD_WR_CMD(0x2C);  //发送显存指令
	LCD_WR_DATA(color);

}


/*	字符显示函数
		显示初始位置：x0,y0
		*pch:显示的字符数据
		forcolor :前景色（字体颜色）
*/

void LCD_ShowChar(uint16_t x0,uint16_t y0,uint8_t pch,uint16_t forcolor)
{
	uint16_t y = y0, x = x0;
	uint8_t i,j,temp,c;
	
	c = pch - ' ' - 1;
	for(i = 0;i < 36;i++)//显示12列，一列24行，共36字节数据
	{
		temp = code[c][i];
		for(j = 0;j < 8;j++)//显示8位
		{
			if(temp&(1<<(7-j)))  //显示按位后为1的位
				LCD_ShowPoint(x,y,forcolor);
			y++;
			if((y-y0) == 24) //若显示已到24行，则要换下一列
			{
				y = y0;
				x++;
			}
		}
	}
	
}

void LCD_ShowString(uint16_t x0,uint16_t y0,uint8_t *pch,uint8_t length,uint16_t forcolor)
{
	uint8_t i = 0;
	uint16_t x = x0;
	for(i=0;i<length;i++)
	{
		LCD_ShowChar(x,y0,pch[i],forcolor);
		x += 6;                           // 可调行距
	}
}


/* 显示中文字符 */
void LCD_ShowChinese(uint16_t x0,uint16_t y0,uint8_t *pch,uint16_t forcolor)
{
	uint16_t y = y0, x = x0;
	uint8_t i,j,temp;

	for(i = 0;i < 72 ;i++)// 显示24列，一列24行，共72字节数据
	{
		temp = pch[i];
		for(j = 0;j < 8;j++)// 按Byte为单位进行显示
		{
			if(temp&(1<<(7-j)))  // 高位在前，从上至下按列显示
				LCD_ShowPoint(x,y,forcolor);
			y++;
			if((y-y0) == 24)
			{
				y = y0;
				x++;
			}
		}
	}
	
}


/* 画线 */
void LCD_DrawLine(uint16_t x0,uint16_t y0,uint16_t x1,uint16_t y1,uint16_t color)
{
	uint16_t lx = abs(x1 - x0); 	
	uint16_t ly = abs(y1 - y0);	
	uint16_t dm,i;
	
	float dx,dy;
	float x,y;
	if(lx > ly)  //分割基准
		dm = lx;
	else
		dm = ly;
	dx = (float)(x1 - x0) / dm;
	dy = (float)(y1 - y0) / dm;
	
	x = (float) x0 + 0.5;
	y = (float) y0 + 0.5;  //四舍五入
	
	for(i = 0;i <= dm; i++)
	{
		LCD_ShowPoint(x,y,color);
		x += dx;
		y += dy;
//		HAL_Delay(10); //加上10ms显示刷新效果
	}
}

/* 画矩形，x,y，左上角起始坐标 */
void LCD_Drawrectangle(uint16_t x,uint16_t y,uint16_t width,uint16_t length,uint16_t color)
{
	
	LCD_DrawLine(x,y,x+width,y,color);
	LCD_DrawLine(x+width,y,x+width,y+length,color);
	LCD_DrawLine(x+width,y+length,x,y+length,color);
	LCD_DrawLine(x,y+length,x,y,color);

}
/* 画实心矩形，x,y，左上角起始坐标 */
void LCD_DrawBlock(uint16_t x,uint16_t y,uint16_t width,uint16_t length,uint16_t color)
{
	uint16_t i;
	for(i = 0;i<=length;i++)
	{
		LCD_DrawLine(x,y+i,x+width,y+i,color);
	}
}
