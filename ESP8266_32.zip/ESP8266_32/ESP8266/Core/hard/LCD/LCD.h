#ifndef __LCD_H_
#define __LCD_H_

#include "main.h"

#define LCD_BL_SET_HIGH() HAL_GPIO_WritePin(GPIOC,GPIO_PIN_10,GPIO_PIN_SET) //开背光
#define LCD_BL_SET_LOW() HAL_GPIO_WritePin(GPIOC,GPIO_PIN_10,GPIO_PIN_RESET) //关背光

#define LCD_CS_SET() HAL_GPIO_WritePin(GPIOC,GPIO_PIN_9,GPIO_PIN_SET) //拉高片选
#define LCD_CS_RESET() HAL_GPIO_WritePin(GPIOC,GPIO_PIN_9,GPIO_PIN_RESET) //拉低片选

#define LCD_RS_SET() HAL_GPIO_WritePin(GPIOC,GPIO_PIN_8,GPIO_PIN_SET) //RS置1
#define LCD_RS_RESET() HAL_GPIO_WritePin(GPIOC,GPIO_PIN_8,GPIO_PIN_RESET) //RS清零

#define LCD_WR_SET() HAL_GPIO_WritePin(GPIOB,GPIO_PIN_4,GPIO_PIN_SET) //WR置1
#define LCD_WR_RESET() HAL_GPIO_WritePin(GPIOB,GPIO_PIN_4,GPIO_PIN_RESET) //WR清零

#define LCD_RD_SET() HAL_GPIO_WritePin(GPIOB,GPIO_PIN_3,GPIO_PIN_SET) //WR置1
#define LCD_RD_RESET() HAL_GPIO_WritePin(GPIOB,GPIO_PIN_3,GPIO_PIN_RESET) //WR清零

typedef struct {
	uint16_t width; //LCD宽度
	uint16_t height; //LCD高度
	uint16_t id; //LCDID
	uint8_t dir; //横屏还是竖屏
}slcd_t;

void LCD_GPIO_Init(void);
void ILI9341_HSD28_Initial(void);
void LCD_Init(void);
void LCD_SetCursor(uint16_t Xpos,uint16_t Ypos);
void LCD_Clear(uint16_t color);
void LCD_Test(void);
void LCD_ShowPoint(uint16_t x,uint16_t y,uint16_t color);
void LCD_ShowChar(uint16_t x0,uint16_t y0,uint8_t pch,uint16_t forcolor);
void LCD_ShowString(uint16_t x0,uint16_t y0,uint8_t *pch,uint8_t length,uint16_t forcolor);
void LCD_ShowChinese(uint16_t x0,uint16_t y0,uint8_t *pch,uint16_t forcolor);
void LCD_Display_Windows(uint16_t dir);
void LCD_DrawLine(uint16_t x0,uint16_t y0,uint16_t x1,uint16_t y1,uint16_t color);
void LCD_Drawrectangle(uint16_t x,uint16_t y,uint16_t width,uint16_t length,uint16_t color);
void LCD_DrawBlock(uint16_t x,uint16_t y,uint16_t width,uint16_t length,uint16_t color);

#endif
