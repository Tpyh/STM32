
/* ���ܣ�ʹSTM32�豸��ͨ��ESP8266ʵ��������ͨ�Ż�������
 * ESP8266��usart2���ӣ�STM32�豸����Դ�������ͨ��
 */

#include "main.h"
#include "usart.h"
#include "gpio.h"
#include "stdio.h"
#include "Key.h"
#include "LCD.h"
#include "ESP8266.h"
#include "LED.h"
uint8_t ok_flag = 0;
uint8_t ready_flag = 0;  		// ESP������־
uint8_t Rcomman_flag = 0;   // ���յ����Ƶ�Ƭ�������־λ �� �û�(�������) -> ESP8266("APmode":������ת) -> ��Ƭ��
uint8_t Rcomman_buf[1] = {0};     // �����������

void SystemClock_Config(void);
void USART12_IT_ENABLE(void);
void ESP8266_MSP_Init(void);
uint8_t AT_RST[]  = "AT+RST\r\n";   		 // ��λ


uint8_t date[] = {"date:2023-12-28"};
uint8_t task[] = {"task:esp8266-test"};




int main(void)
{

	
	uint8_t key_num = 0;
  HAL_Init();
  SystemClock_Config();
  MX_GPIO_Init();
	ESP8266_MSP_Init();
	LCD_Init();
	Key_Init();
	LED_Init();
	
	LCD_Clear(0x0000);
	LCD_ShowString(10,20,date,sizeof(date) - 1,0x001f); // -1:����ʾ"/0"�ַ���������
	LCD_ShowString(10,44,task,sizeof(task) - 1,0x001f);
	while(!ready_flag)
	{
		HAL_UART_Transmit(&huart2,AT_RST,sizeof(AT_RST),10);
		HAL_Delay(1000);
	}
	printf("ESP8266��������\r\n");
	ESP8266_AP_MODE();
	
  while (1)
  {
		key_num = Key_Scan();

		if(key_num == KEY0)
		{
			ESP8266_AP_SendDATA((uint8_t *)"temperature:23",0,11);
			if(ok_flag == 1)
				printf("���ͳɹ�!\r\n");
		}
		if(key_num == WK_UP)
		{
			ESP8266_AP_SendDATA(date,0,sizeof(date));
			if(ok_flag == 1)
				printf("���ͳɹ�!\r\n");
			ESP8266_AP_SendDATA((uint8_t *)"time:11:00",0,10);
			if(ok_flag == 1)
				printf("���ͳɹ�!\r\n");
		}
		if(Rcomman_flag == 1)
		{
			HAL_Delay(100);
			if(Rcomman_buf[0] != 0)
			{	
				printf("\r\ncomman =  %c\r\n",Rcomman_buf[0]);
				Rcomman_flag = 0;
				if(Rcomman_buf[0] == '1')
					LED_Set(LED0,ON);
				if(Rcomman_buf[0] == '2')
					LED_Set(LED0,OFF);
			}
		}
		
		
  }

}







void USART12_IT_ENABLE(void)
{
	__HAL_UART_ENABLE_IT(&huart1,UART_IT_RXNE);
	__HAL_UART_ENABLE_IT(&huart1,UART_IT_IDLE);
	__HAL_UART_ENABLE_IT(&huart2,UART_IT_RXNE);
	__HAL_UART_ENABLE_IT(&huart2,UART_IT_IDLE);	
}

void ESP8266_MSP_Init(void)
{
	MX_USART1_UART_Init();
  MX_USART2_UART_Init();
	USART12_IT_ENABLE();
}

// printf�ض���
int fputc(int ch,FILE *f)
{
	uint8_t data[] = {ch};
	HAL_UART_Transmit(&huart1,data,1,10);
	return ch;
}













/*----------------------------------------------------------------------ϵͳ��غ���---------------------------------------------------------------------------*/
/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
