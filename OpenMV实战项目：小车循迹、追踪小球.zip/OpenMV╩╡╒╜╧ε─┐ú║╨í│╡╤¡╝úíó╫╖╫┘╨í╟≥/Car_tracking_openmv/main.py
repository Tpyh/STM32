import sensor,image,time
from pyb import LED
from pyb import UART
import ustruct

#LINE_threshold = (5,34,-23,32,-12,11) # 线颜色阈值
LINE_threshold =(64, 0, 60, -96, -40, 115)
# LED(1).on()
# LED(2).on()
# LED(3).on()  #补光

sensor.reset()
sensor.set_vflip(True)   # 打开垂直翻转，不开启会导致画面方向与运动方向相反
sensor.set_hmirror(True) # 打开水平翻转，不开启会导致画面方向与运动方向相反
sensor.set_pixformat(sensor.RGB565) # 像素格式
sensor.set_framesize(sensor.QQVGA) # 分辨率 160*120

sensor.skip_frames(time = 2000) # 使摄像头稳定
clock = time.clock()            # 记录帧率

uart = UART(3, 9600)   #P4:TX P5: RX  地需与STM32相连
uart.init(9600, bits=8, parity=None, stop=1)

# roi区域
track_roi=[(0,55,10,10),
           (10,55,10,10),
           (20,55,10,10),
           (30,55,10,10),
           (40,55,10,10),
           (50,55,10,10),
           (60,55,10,10),
           (70,55,10,10),
           (80,55,10,10),
           (90,55,10,10),
           (100,55,10,10),
           (110,55,10,10),
           (120,55,10,10),
           (130,55,10,10),
           (140,55,10,10),
           (150,55,10,10)]

hor_bits=['0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0'] #记录横线16个感兴趣区是否为黑线
targetx = 0  # 用来记录16个roi中符合寻找色块阈值的区域

def find_track():
    global targetx
    targetx=0
    img = sensor.snapshot()

    for i in range(0,16):
        hor_bits[i] = 0
        # merge=True 重叠的色块合并为一个
        # margin =10,两个距离10像素的色块将合并
        blobs = img.find_blobs([LINE_threshold],roi=track_roi[i],merge=True,margin=10)
        for b in blobs:
            hor_bits[i] = 1

    # 标记找到符合颜色阈值的区域
    for k in range(0,16):
        if (hor_bits[k]):
            img.draw_circle(int(track_roi[k][0] + track_roi[k][2]*0.5),int(track_roi[k][1]+track_roi[k][3]*0.5),1,(255,0,0))
            targetx = targetx |1<<(15 - k)

    for rec in track_roi:
        img.draw_rectangle(rec, color=(0,0,255))#绘制出roi区域

def Get_xError():
    global targetx
    bsum = 0
    cnt = 0
    xerror = 0
    for i in range(0,16):
        if(targetx&(1<<(15-i))):
            bsum += (track_roi[i][0] + track_roi[i][2]*0.5)
            cnt += 1
    if cnt:
        xerror = 80 - (bsum / cnt) # 获得中间位置与路线的误差
    return xerror

# 误差转换
def Error_transform(xerror):
    global dire
    xerror *= 100
    dire = 0
    if(xerror<0):
      xerror *= -1
      dire = 1
    tran_error = int(xerror)
    return tran_error


def send_data(data):
    global uart
    global dire
    x1 = (data&0xff00)>>8
    x2 = data&0x00ff

    FH = bytearray([0x1a,x1,x2,dire,0x2b])
    uart.write(FH)


dire = 0    # 记录方向
xerror = 0  # 存误差
targetb = 0x0000 # 存误差转换值

while(True):

    clock.tick()
    find_track()
    xerror = Get_xError()   # 获得路线与小车的偏差
    targetb = Error_transform(xerror) # 误差转换
    send_data(targetb) # 发送路径误差数据至小车控制端
    print(xerror,targetb,dire)


