#ifndef __L298N_H
#define __L298N_H


#define Foreword 1
#define Reversal 2
#define Braking  3


void L289N_Init(uint16_t psc,uint16_t arr);
void L289N_GIPO_Init(void);
void Timer3_Init(uint16_t psc,uint16_t arr);
void PWM_Enable(void);
void PWM_Disable(void);
void PWM_CH1_Set(uint16_t ccr);
void PWM_CH2_Set(uint16_t ccr);
void Car_Wheel1(uint8_t mode);
void Car_Wheel2(uint8_t mode);

#endif

