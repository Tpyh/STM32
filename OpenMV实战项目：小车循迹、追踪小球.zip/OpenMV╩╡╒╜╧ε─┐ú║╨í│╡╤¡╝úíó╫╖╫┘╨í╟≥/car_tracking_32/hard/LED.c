#include "stm32f10x.h"
#include "LED.h"
#include "Sys.h"

void LED_Init()
{
	RCC->APB2ENR |= 1<<6;
	
	Px_OUT_PP_50MHz(GPIOE,1<<12|1<<13);
	
	GPIOE->ODR |= (uint16_t)(1<<12);
	GPIOE->ODR |= (uint16_t)(1<<13);

}

//LEDx:LED0 OR LED1; 
//state: ON OR OFF
void LED_Set(uint8_t LEDx,uint8_t state)
{
	if(LEDx == LED0)
	{
		if(state == ON)
		{
				GPIO_Pin_Set(GPIOE,1<<12,RESET);
		}
		else if(state == OFF)
		{
				GPIO_Pin_Set(GPIOE,1<<12,SET);
		}
	}
	else if(LEDx == LED1)
	{
		if(state == ON)
		{
				GPIO_Pin_Set(GPIOE,1<<13,RESET);
		}
		else if(state == OFF)
		{
				GPIO_Pin_Set(GPIOE,1<<13,SET);
		}
	}
}




