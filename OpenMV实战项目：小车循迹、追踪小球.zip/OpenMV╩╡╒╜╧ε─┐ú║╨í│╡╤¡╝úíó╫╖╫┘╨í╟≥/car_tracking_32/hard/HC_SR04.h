#ifndef __HC_SR04_H
#define __HC_SR04_H



void Timer2_Init(void);
void HC_SR04_GPIO_Init(void);
void HC_SR04_Init(void);
void EnableTimer2(void);
void DisableTimer2(void);
float HC_SR04_GetLength(void);




#endif

