#include "stm32f10x.h"
#include "Delay.h"
#include "Key.h"
#include "Sys.h"

void Key_Init(void)
{
	RCC->APB2ENR |= 1<<6;
	RCC->APB2ENR |= 1<<2;
	// PE2�������룬PA0��������
	Px_SET_IN(GPIOE,1<<2,1);
	Px_SET_IN(GPIOA,1<<0,0);
}


uint8_t Key_Scan(void)
{
	static uint8_t keyflag = 1;
	if((((GPIOE->IDR & 1<<2) == 0)||((GPIOA->IDR & 1<<0) == 1)) && keyflag == 1)
	{	
		Delay_ms(10);
		if((GPIOE->IDR & 1<<2) == 0)
		{
			keyflag = 0;
			return KEY0;
		}
		if((GPIOA->IDR & 1<<0) == 1)
		{
			keyflag = 0;
			return WK_UP;
		}
	}
	if((((GPIOE->IDR & 1<<2) != 0)&&((GPIOA->IDR & 1<<0) == 0)) && keyflag == 0)
		keyflag = 1;
	return 0;
}

void Key_Matrix_Init(void)
{
	
	RCC->APB2ENR |= 1<<6;
	PE4_7IN_PE8_11OUT();
}

void PE4_7IN_PE8_11OUT(void)
{
	Px_SET_IN(GPIOE,1<<4|1<<5|1<<6|1<<7,1);  				//��������
	Px_OUT_PP_50MHz(GPIOE,1<<8|1<<9|1<<10|1<<11);		//�������
}
void PE4_7OUT_PE8_11IN(void)
{
		Px_SET_IN(GPIOE,1<<8|1<<9|1<<10|1<<11,1);
		Px_OUT_PP_50MHz(GPIOE,1<<4|1<<5|1<<6|1<<7);
}


uint8_t Key_MatrixScan(void)
{
	uint8_t keynum = 0;
	static uint8_t keyflag = 1; 
	PE4_7IN_PE8_11OUT();
	GPIO_Pin_Set(GPIOE,1<<8|1<<9|1<<10|1<<11,RESET); //��������͵�ƽ
	if(((GPIOE->IDR&0xf0) != 0xf0) && keyflag == 1)
	{
		Delay_ms(10);
		if((GPIOE->IDR&0xf0) != 0xf0)
		{
			keynum |= (uint8_t)0xf0&GPIOE->IDR;
			PE4_7OUT_PE8_11IN();
			GPIO_Pin_Set(GPIOE,1<<4|1<<5|1<<6|1<<7,RESET); //��������͵�ƽ
			if((GPIOE->IDR&0xf00) != 0xf00)
			{
				Delay_ms(10);
				if((GPIOE->IDR&0xf00) != 0xf00)
				{	
					keynum  = keynum>>4;
					keynum |= (GPIOE->IDR & 0xf00)>>4;
				}
			}
			keyflag = 0;
			return keynum;
		}
	}
	if(((GPIOE->IDR&0xf0) == 0xf0) && keyflag == 0)
	{
		keyflag = 1;
	}
	return keynum;
}


