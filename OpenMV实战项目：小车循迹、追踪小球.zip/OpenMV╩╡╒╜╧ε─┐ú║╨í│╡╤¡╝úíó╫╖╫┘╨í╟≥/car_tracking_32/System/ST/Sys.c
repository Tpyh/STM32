#include "stm32f10x.h"

/*
	*GPIOx :x(A-F)
	*GPIO_PIN:PIN0 - PIN15  
	*State :SET OR RESET
*/
void GPIO_Pin_Set(GPIO_TypeDef * GPIOx,uint16_t GPIO_PIN,uint8_t State)
{
	
	if(State == SET)
		GPIOx->BSRR |= GPIO_PIN;
	else
		GPIOx->BSRR |= (uint32_t)GPIO_PIN<<16;

}


void mNVIC_PriorityGroupGonfig(uint32_t NVIC_PriorityGroup)
{
	uint32_t temp;
	temp = SCB->AIRCR;
	temp &= 0x0000F8FFF; //�����ǰ����
	temp |= 0x05FA0000;  //д����Կ������д���µ��ж����ȼ�����
	temp |= ((uint32_t)7<<8 & ((~NVIC_PriorityGroup)<<8));
	SCB->AIRCR = temp;   //���÷���
	
}

/* pre:��ռ���ȼ���sub:�����ȼ���group:���ȼ����� */
void mNVIC_PrioritySet(uint16_t pre,uint16_t sub,uint8_t NVIC_Channel,uint8_t group)
{
	uint32_t pri = 0;
	pri |= pre << (4 - group); 
	pri |= sub & (0xf>>group);
	
	pri |=0xf;
	NVIC->IP[NVIC_Channel] |= pri<<4;  //����λ�����ж����ȼ�
	NVIC->ISER[NVIC_Channel/32] |= 1<<(NVIC_Channel%32); //ʹ���ж�
}


/* �жϵ�ʹ����ʧ�� */
void mNVIC_PriorityPower(uint8_t power,uint8_t NVIC_Channel)
{
	if(power == ENABLE)
		NVIC->ISER[NVIC_Channel/32] |= 1<<(NVIC_Channel%32);
	else
		NVIC->ICER[NVIC_Channel/32] |= 1<<(NVIC_Channel%32);
}


void EXTI2_Init(void)
{
	RCC->APB2ENR |= 1<<6;	
	GPIOE->CRL &= (0xf<<(4*4)); 
	GPIOE->CRL |= (8<<(4*4));//����ģʽ
	GPIOE->ODR &= ~(1<<4); 	 //����
	
	AFIO->EXTICR[4/4] &= ~(0xf<<((4%4)*4));
	AFIO->EXTICR[4/4] |= 4<<((4%4)*4);							//�ж���4ӳ����PE4
	
	EXTI->IMR |= 1<<4;    //������4�ж�
	EXTI->RTSR |= 1<<4;   //�����ش���
	
//	NVIC->IP[EXTI4_IRQn] |= pri <<4;
//	NVIC->ISER[EXTI4_IRQn/32] |= 1<<(EXTI4_IRQn % 32);  //ʹ���ж�
	mNVIC_PrioritySet(0,2,EXTI4_IRQn,2);
	
}


void Px_OUT_PP_50MHz(GPIO_TypeDef * GPIOx,uint16_t pin)
{
	uint16_t i = 0;
	for(i = 0;i < 15;i++)
	{
		if(pin & 1<<i)
		{
			if(i <= 7)
			{	
				GPIOx->CRL &= ~((uint32_t)0xf<<(i*4));
				GPIOx->CRL |= (uint32_t)3<<(i*4);
			}
			else
			{
				GPIOx->CRH &= ~((uint32_t)0xf<<((i - 8)*4));
				GPIOx->CRH |= (uint32_t)3<<((i - 8)*4);
			}
		}
	}
}

void Px_OUT_PP_10MHz(GPIO_TypeDef * GPIOx,uint16_t pin)
{
	uint16_t i = 0;
	for(i = 0;i < 15;i++)
	{
		if(pin & 1<<i)
		{
			if(i <= 7)
			{	
				GPIOx->CRL &= ~((uint32_t)0xf<<(i*4));
				GPIOx->CRL |= (uint32_t)1<<(i*4);
			}
			else
			{
				GPIOx->CRH &= ~((uint32_t)0xf<<((i - 8)*4));
				GPIOx->CRH |= (uint32_t)1<<((i - 8)*4);
			}
		}
	}
}
// pupd :1:������0������
void Px_SET_IN(GPIO_TypeDef * GPIOx,uint16_t pin,uint8_t pupd)
{
	uint16_t i = 0;
	for(i = 0;i < 15;i++)
	{
		if(pin & 1<<i)
		{
			if(i <= 7)
			{	
				GPIOx->CRL &= ~((uint32_t)0xf<<(i*4));
				GPIOx->CRL |= (uint32_t)8<<(i*4);
				if(pupd)
					GPIOx->ODR |= 1<<i;  //����ʹ��
			}
			else
			{
				GPIOx->CRH &= ~((uint32_t)0xf<<((i - 8)*4));
				GPIOx->CRH |= (uint32_t)8<<((i - 8)*4);
				if(pupd)
					GPIOx->ODR |= 1<<i;//����ʹ��
			}
		}
	}
}
//�����������
void Px_OUT_AFPP_50MHz(GPIO_TypeDef * GPIOx,uint16_t pin)
{
	uint16_t i = 0;
	for(i = 0;i < 15;i++)
	{
		if(pin & 1<<i)
		{
			if(i <= 7)
			{	
				GPIOx->CRL &= ~((uint32_t)0xf<<(i*4));
				GPIOx->CRL |= (uint32_t)11<<(i*4);
			}
			else
			{
				GPIOx->CRH &= ~((uint32_t)0xf<<((i - 8)*4));
				GPIOx->CRH |= (uint32_t)11<<((i - 8)*4);
			}
		}
	}
}
