#include "stm32f10x.h"
#include "stdio.h"

#include "Sys_Clock.h"
#include "Sys.h"
#include "Delay.h"
#include "mUSART.h"

#include "HC_SR04.h"
#include "LED.h"
#include "Key.h"
#include "L298N.h"
#include "Car.h"
#include "mPID.h"

uint8_t path_data[3];
uint8_t rx_flag = 0;
int16_t r = 200;
int16_t l = 200;
float path_error = 0;
float Car_error_Transform(void);

_pid Car_pid;    // ����С����PID����

int main()
{

	mNVIC_PriorityGroupGonfig(2);
	System_Init();
	mUSART_Init();
	mUSART2_Init();
	LED_Init();
	Key_Init();
	Car_Init();

	Car_pid = PID_Init(0,0,120,0);
	Car_pid.Kp = 1.5;
	Car_pid.Ki = 0;  // ��ʹ�û�����
	Car_pid.Kd = 6;
	
	LED_Set(LED0,ON);

	while(1)
	{
		path_error = Car_error_Transform();
		Car_pid.current = path_error;
		pid_calculate(&Car_pid);
		Delay_ms(1000);
		Car_Run(200-Car_pid.total_out,200+Car_pid.total_out);
		printf("Car_pid.total_out = %f\r\n",Car_pid.total_out);
		printf("path_error = %f\r\n",path_error);
		
	}

}


float Car_error_Transform(void)   // ת��С����·�ߵ����
{
	float data = 0;
	if(rx_flag == 1)
	{
			rx_flag = 0;
			data = (path_data[0]<<8) | path_data[1];    // ����ͷ�˷������ݣ���λ����
			data = data / 100;
			if(path_data[2] == 1)
			{
				 data *= -1;
			}
	}
	return data;
}
