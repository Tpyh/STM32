#include "stm32f10x.h"
#include "Sys.h"
#include "L298N.h"
#include "Car.h"


void Car_Init(void)
{
		L289N_Init(3599,449);
		PWM_Enable();
}

void Car_Run(int16_t left_speed,int16_t right_speed)
{
		if(left_speed < 0)
		{
			left_speed *= -1;
			Car_Wheel1(Reversal);
		}
		else
			Car_Wheel1(Foreword);
		
		if(right_speed < 0)
		{
			right_speed *= -1;
			Car_Wheel2(Reversal);
		}
		else
			Car_Wheel2(Foreword);
		
		if(left_speed > 449)
			left_speed = 449;
		if(right_speed > 449)
			right_speed = 449;
		
		PWM_CH1_Set(left_speed);
		PWM_CH2_Set(right_speed);
		
}

void Car_Stop(void)
{
	Car_Wheel1(Braking);
	Car_Wheel2(Braking);
}

