#include "mPID.h"
#include <math.h>




_pid PID_Init(float target,float Ilimit,float MaxOutput,float Iband)
{
	_pid xpid;
	xpid.target = target;
	xpid.Iband  = Iband;
	xpid.Ilimit = Ilimit;
	xpid.MaxOutput = MaxOutput;
	return xpid;
	
}


void limit(float *i,float j)
{
	
	
	if(*i > j)
	{
		*i = j;
	}
	if(*i < -j)
	{
		*i = -j;
	}
}

void pid_calculate(_pid * pid)
{
	pid->error = pid->target - pid->current;
	pid->p_out = pid->Kp * pid->error;
	
	// ���ַ���
	if((float)fabs(pid->error) < pid->Iband)
	{
		pid->i_out += pid->Ki * pid->error;
		limit(&pid->i_out,pid->Ilimit);   // �����޷�
	}
	else
	{
		// �����޶�ֵ����������ã���ֹ��绷��ͻ�䣬���¿���ϵͳ�쳣
		pid->i_out = 0;          
	}
	
	pid->d_out = pid->Kd * (pid->last_error - pid->error);
	pid->total_out = pid->p_out + pid->i_out + pid->d_out;
	limit(&pid->total_out,pid->MaxOutput);
	pid->last_error = pid->error;
	
}


