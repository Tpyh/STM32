#ifndef __CAR_H
#define __CAR_H



void Car_Init(void);
void Car_Run(int16_t left_speed,int16_t right_speed);
void Car_Stop(void);



#endif

