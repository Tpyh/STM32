# Untitled - By: 29077 - Mon Oct 30 2023
#导入感光元件、图像处理、定时器模块
import sensor, image, time

#初始化感光元件
sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QVGA)  #分辨率为：320*240
sensor.skip_frames(time = 2000)  #等待感光元件稳定

#颜色追踪需关闭自动增益和白平衡
sensor.set_auto_gain(False)
sensor.set_auto_whitebal(False)


clock = time.clock()
mthreshold = (70, 17, 24, 112, -9, 59)

#1.记忆色块阈值,r，循环执行200次
#ange（200）：生成0-199共200个顺序数
#for i in range(200):
#   img.draw_rectangle((150,110,20,20),color = (255,0,0))
 #   Statistics = img.get_statistics(roi = (150,110,20,20)) #在目标区域中统计图像信息

    #从统计信息中获得色块的阈值
  #  Threshold = [Statistics.l_min(),Statistics.l_max(),
   #              Statistics.a_min(),Statistics.a_max(),
    #             Statistics.b_min(),Statistics.b_max()]

while(True):
    clock.tick()
    img = sensor.snapshot()
    blobs = img.find_blobs([mthreshold])
    #寻找记忆色块
    #area_threshold：色块的最小面积区域，小于此阈值的色块将被过滤
    if blobs:
        for blob in blobs:
            img.draw_rectangle((blob[0:4]))
            img.draw_cross(blob.cx(),blob.cy())
            print(blob.cx(),blob.cy())

    print(clock.fps())
